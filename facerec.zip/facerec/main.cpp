#include "facerec.h"

int main(){
    int nop = 500;
    int people = 10;
    int s = 3;
    int n = 7;

    auto pixels = choose_pixels(nop);

    auto base = make_base(people, pixels, nop, 1);

    auto base2 = make_base(people, pixels, nop, 5);
    base2 = add_bases(base, base2, nop, people);

    int* res = new int[people];
    auto target = extract_vector_and_delete_matrix(make_arr(s, n), pixels, nop);
    for (int i = 0; i < people; i++){
        res[i] = calculate_difference(base[i], target, nop);
    }
    cout << "RESULT" << endl;

    for (int i = 0; i < people; i++) {
        cout << res[i] << endl;
        delete [] base[i];
    }

    cout << "RESULT2" << endl;

    for (int i = 0; i < people; i++){
        res[i] = calculate_difference(base2[i], target, nop);
    }
    for (int i = 0; i < people; i++) {
        cout << res[i] << endl;
        delete [] base2[i];
    }

    delete [] base;
    delete [] res;
    delete [] target;
    delete [] pixels;
    return 0;
}